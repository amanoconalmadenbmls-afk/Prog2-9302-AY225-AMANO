import java.awt.*;
import java.time.LocalDateTime;
import java.util.UUID;
import javax.swing.*;

/**
 * Attendance Tracker Application
 * ---------------------------------------
 * Features:
 * - Displays JFrame window
 * - Input fields for: Attendance Name, Course/Year
 * - Auto-filled Time In using system date/time
 * - Auto-generated E-Signature using UUID
 * - Clean layout using GridBagLayout
 * - Fully commented code
 */

public class AttendanceTracker {

    public static void main(String[] args) {

        // Create the main window
        JFrame frame = new JFrame("Attendance Tracker");
        frame.setSize(450, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null); // Center the window

        // Use GridBagLayout for clean alignment
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(8, 8, 8, 8); // Padding around components
        c.fill = GridBagConstraints.HORIZONTAL;

        // ---------- LABELS & TEXTFIELDS ----------
        JLabel nameLabel = new JLabel("Attendance Name:");
        JTextField nameField = new JTextField();

        JLabel courseLabel = new JLabel("Course/Year:");
        JTextField courseField = new JTextField();

        JLabel timeLabel = new JLabel("Time In:");
        JTextField timeField = new JTextField();
        timeField.setEditable(false); // Auto-filled, user cannot edit

        JLabel signatureLabel = new JLabel("E-Signature:");
        JTextField signatureField = new JTextField();
        signatureField.setEditable(false);

        // ---------- FILL SYSTEM TIME ----------
        String timeIn = LocalDateTime.now().toString();
        timeField.setText(timeIn);

        // ---------- GENERATE UNIQUE SIGNATURE ----------
        String eSignature = UUID.randomUUID().toString();
        signatureField.setText(eSignature);

        // ---------- ADD COMPONENTS TO PANEL ----------
        c.gridx = 0; c.gridy = 0; panel.add(nameLabel, c);
        c.gridx = 1; panel.add(nameField, c);

        c.gridx = 0; c.gridy = 1; panel.add(courseLabel, c);
        c.gridx = 1; panel.add(courseField, c);

        c.gridx = 0; c.gridy = 2; panel.add(timeLabel, c);
        c.gridx = 1; panel.add(timeField, c);

        c.gridx = 0; c.gridy = 3; panel.add(signatureLabel, c);
        c.gridx = 1; panel.add(signatureField, c);

        // Add the panel to frame
        frame.add(panel);

        // Display the window
        frame.setVisible(true);
    }
}
